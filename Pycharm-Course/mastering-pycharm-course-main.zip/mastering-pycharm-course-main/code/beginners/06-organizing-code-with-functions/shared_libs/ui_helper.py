def show_header():
    print("---------------------------")
    print(" Rock Paper Scissors")
    print("  Function Edition")
    print("---------------------------")
