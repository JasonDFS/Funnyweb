# Your turn: Tool windows

This chapter doesn't have a *your turn*. Just play with the various windows.
The ones mentioned in this chapter -- sorted chronologically -- were:

* TODOs (use excluded directories to filter)
* Run (check line wrap, scroll, pause, re-run)
* Python Console
* Terminal
* Favorites (create bookmarks and navigate breakpoints)
* Structure

*See a mistake in these instructions? Please [submit a new issue](https://github.com/talkpython/mastering-pycharm-course/issues) or fix it and [submit a PR](https://github.com/talkpython/mastering-pycharm-course/pulls).*