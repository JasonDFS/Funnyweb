def other_method(text):
    print(f"This is the other method: {text}!")
