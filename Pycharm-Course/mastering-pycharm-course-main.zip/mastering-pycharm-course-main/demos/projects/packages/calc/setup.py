from setuptools import setup

setup(
    name='calc',
    version='0.1.0',
    packages=['calc'],
    url='https://github.com/talkpython/calc',
    license='MIT',
    author='Michael Kennedy',
    author_email='michael@talkpython.fm',
    description='The best calculator ever, don\'t you think?'
)
