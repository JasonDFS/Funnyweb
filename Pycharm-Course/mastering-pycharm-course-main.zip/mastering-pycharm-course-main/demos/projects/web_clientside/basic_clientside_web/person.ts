
class Person {
    constructor(public firstName: string,
                public lastName: string,
                public age: number) {
    }
}
