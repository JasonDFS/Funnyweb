from test_client import *

# Let's be sure to use conftest.py for sharing fixtures across multiple files
# Added after the recording but will help some folks.
# For more info, see:
# https://docs.pytest.org/en/6.2.x/fixture.html#conftest-py-sharing-fixtures-across-multiple-files
