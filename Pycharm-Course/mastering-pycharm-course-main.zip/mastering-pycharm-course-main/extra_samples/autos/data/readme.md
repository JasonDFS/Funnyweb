# Vehicle data

Since this data is so large and appears to be no longer available on the website as a CSV, we are including it here. But you'll need to unzip the file to this folder to load it.

Downloaded from [www.fueleconomy.gov/feg/ws/index.shtml](https://www.fueleconomy.gov/feg/ws/index.shtml)
