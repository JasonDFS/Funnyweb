



function runAtLoad() {
    person = "Paul"

    console.log("Nice to meet you" + person)
  }

  runAtLoad()
